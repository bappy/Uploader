<?php
//define("site","http://iter8.co/uploader");
define("site","http://localhost/jquery");
define("size_limit","15346");
?>